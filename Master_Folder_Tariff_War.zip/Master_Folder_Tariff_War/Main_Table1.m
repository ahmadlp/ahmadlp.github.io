%------------------------------------------------------------------------------------------------%
%                          This File Produces Table 1
%------------------------------------------------------------------------------------------------%
%                        Description of Key Variables
% ------------------------------------------------------------------------------------------------
%   N: number of countries;  S: umber of industries  
%   A varibale with a name ending in "3D" correponds to a 3D cube with size N*N*S;  
%   Element Z(i,j,k) of 3D cude Z correponds to "origin i- destination j - industry k" 
%   sigma_k3D: industry-level CES parameter (sigma-1 ~ theta ~ trade elasticity)
%   tji_k3D: applied tariff rates (origin j-destination i-industry k) ---source: TRAINS, 2014
%   X_ji,k = expenditure level (origin j-destination i-industry k) --- source: WIOD 2014
%   See Section 5.1 for a detailed description of the data. 
% ------------------------------------------------------------------------------------------------
        clear all
        clc
        cd '~/Master_Folder_Tariff_War'

     %========================= Baseline Model ======================== 

        load './Cleaned_Data_Files/WIOT2014'
        Xjik_3D = Xijs_new3D;
        lambda_jik3D=Xjik_3D./repmat(sum(Xjik_3D,1), [ N 1 1]) ; 
        Yi3D=repmat(sum(sum(Xjik_3D,1),3)', [ 1 N S]); Ri3D=repmat(sum(sum(Xjik_3D./(1+tjik_3D),2),3), [ 1 N S]) ;
        e_ik3D = repmat(sum(Xjik_3D,1), [ N 1 1])./ permute(Yi3D, [2 1 3]);
        clearvars Xijs_new3D;
       
        %----------- Compute the Counterfactual Nash Equilibrium -------------% 
        T0=[1.1*ones(N,1); 1.1*ones(N,1); 1.5*ones(N,1)];
        target = @(X) Trade_War_Baseline(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, tjik_3D);
        options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,'TolX',1e-14, 'algorithm','levenberg-marquardt'); 
        X_sol=fsolve(target,T0, options);

        %-----------  Save Nash Tariffs & their Welfare Cost  -------------% 
         Nash_Tariff = 100*(X_sol(2*N+1:end)-1);
         Cost_of_Tariff_War = Welfare_Gains_Baseline(X_sol, N , S, e_ik3D, sigma_k3D, lambda_jik3D, tjik_3D);
         save Results_Baseline.mat Nash_Tariff Cost_of_Tariff_War 
         
                  
 
    %============  MC Model (Baseline + Markup Distortions) =============
        clear
        load './Cleaned_Data_Files/WIOT2014_MC'
        Xjik3D= Xijs_new3D; Yi3D = repmat(sum(sum(Xjik3D,1),3)', [1 N S]);
        lambda_jik3D = Xjik3D./repmat(sum(Xjik3D,1), [N 1 1]);
        e_ik3D= repmat(sum(Xjik3D,1), [N 1 1])./permute(Yi3D, [2 1 3]);
        Ri3D=repmat(sum(sum(Xjik3D./((1+tjik_3D).*(1+mu_k3D)),2),3), [ 1 N S]) ;
        clearvars Xijs_new3D;
       
        %----------- Compute the Counterfactual Nash Equilibrium -------------% 
        T0=[1.15*ones(N,1); 1.15*ones(N,1); 1.2*ones(N*S,1)];
        target = @(X) Trade_War_MC(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, mu_k3D, tjik_3D);
        options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,'TolX',1e-14, 'algorithm','levenberg-marquardt');
        X_sol=fsolve(target,T0, options);

        %-----------  Save Nash Tariffs & their Welfare Cost  -------------% 
         tjik = abs(X_sol(N+N+1:end));
         AUX0 = repmat(reshape(tjik,1,N,S), [N 1 1]);
         AUX1 =  repmat(eye(N), [1 1 S]) + AUX0.*repmat(1-eye(N), [1 1 S]) - 1 ;
         Nash_Tariff_MC = 100*(mean(sum(AUX1,1)/43,3))';
 
         Cost_of_Tariff_War_MC = Welfare_Gains_MC(X_sol, N , S, e_ik3D, sigma_k3D, lambda_jik3D, tjik_3D);
         save Results_MC.mat Nash_Tariff_MC Cost_of_Tariff_War_MC 
 


   %================= Integrated Model (Baseline + IO + Distortion) ================= 
        clear
        load './Cleaned_Data_Files/WIOT2014_Integrated'
        rev_share = permute(reshape(gamma_tilde',N,N,S),[2 1 3]);
        AUX0 = rev_share .* repmat(sum(Xjik3D./((1+tjik_3D).*(1+mu_k3D)), 2), [1 N, 1]);
        Ri3D=repmat(sum(sum(AUX0, 1),3)', [1 N S]);
        Yi3D=repmat(sum(sum(Xjik3D, 1),3)', [1 N S]);
        lambda_jik3D = Xjik3D./repmat(sum(Xjik3D,1), [N 1 1]);
        e_ik3D = repmat(sum(Xjik3D,1), [N 1 1])./repmat(sum(sum(Xjik3D,1),3), [N 1 S]); 

        %----------- Compute the Counterfactual Nash Equilibrium -------------% 
        T0=[1.1*ones(N,1); 1.1*ones(N,1); 1.5*ones(N,1); 1.2*ones(N,1); 1.1*ones(N*S,1)];
        target = @(X) Trade_War_Integrated(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, mu_k3D, gamma_tilde, rev_share, tjik_3D);
        options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,'TolX',1e-14, 'algorithm','levenberg-marquardt'); 
        X_sol=fsolve(target,T0, options);
        
        %-----------  Save Nash Tariffs & their Welfare Cost  -------------% 
         tau = abs(X_sol(N+N+1:N+N+N));
         mu_avg = abs(X_sol(N+N+N+1:N+N+N+N));
         Multiplier = abs(X_sol(N+N+N+N+1:end));
         rho = permute(rev_share, [2 1 3]).*(1 - (mu_avg./(1 + mu_k3D)));
         tjik =  kron(Multiplier, ones(N-1,1)).*(1 + repmat(kron(tau,ones(N-1,1)),S,1) - rho(repmat(eye(N),[1 1 S])==0)) - 1;
         
         Nash_Tariff_Integrated = 100*(mean(mean(reshape(tjik,N-1,N,S),1),3))';
         Cost_of_Tariff_War_Integrated = Welfare_Gains_Integrated(X_sol, N , S, e_ik3D, sigma_k3D, lambda_jik3D, gamma_tilde, tjik_3D, mu_k3D, rev_share);



    % --------------------------------------------------------------------------------------
    %                       Step 3: Print Output
    % --------------------------------------------------------------------------------------
        load Results_Baseline.mat; load Results_MC.mat;
        [num, text, raw] = xlsread('./Data_Preperation_Files/Country_List.xlsx');
        % Names of countries start with raw 3 of column 1:
        countries = text(1:end, 1);
        % Fix the last name, which is an aggregation of several countries
        countries(end) = cellstr('RoW');

        Table = [ Nash_Tariff Cost_of_Tariff_War      Nash_Tariff_MC Cost_of_Tariff_War_MC     Nash_Tariff_Integrated Cost_of_Tariff_War_Integrated];

        tablePreamble = {...
        '\begin{tabular}{lccccccccc}';
        '\toprule';
        '& ';
        '\multicolumn{2}{c}{ \specialcell{Baseline Model} } &&';
        '\multicolumn{2}{c}{\specialcell{Baseline + distortions} } &&';
        '\multicolumn{2}{c}{\specialcell{Baseline + distortions + IO} } \\';
        '\addlinespace[3pt]';
        '\cline{2-3}';
        '\cline{5-6}';
        '\cline{8-9}'
        '\addlinespace[3pt]';
        'Country &';
        'Nash Tariff &';
        '\specialcell{\%$\Delta$ Real GDP} &&';
        'Nash Tariff &';
        '\specialcell{\%$\Delta$ Real GDP} &&';
        'Nash Tariff &';
        '\specialcell{\%$\Delta$ Real GDP} \\';

        '\midrule'
        };

        tableClosing = {...
        ' \bottomrule';
        '\end{tabular}'
        };

        fileID = fopen('Table_1.tex', 'w');

        %%% TABLE PREAMBLE   %%%
        for i = 1:size(tablePreamble)
            fprintf(fileID, '%s\n', char(tablePreamble(i)));
        end

         %%%  COLUMNS WITH RESULTS %%%
        for i = 1:N-1
            fprintf(fileID, '%s & ', char(countries(i)));
            fprintf(fileID, '%1.1f\\%% & ', Table(i, 1));
            fprintf(fileID, '%1.2f\\%% && ', Table(i, 2));
            fprintf(fileID, '%1.1f\\%% & ', Table(i, 3));
            fprintf(fileID, '%1.2f\\%% && ', Table(i, 4));
            fprintf(fileID, '%1.1f\\%% & ', Table(i, 5));
            fprintf(fileID, '%1.2f\\%% \\\\ ', Table(i, 6));
        end

        %%%  WRITE AVERAGES %%%
        fprintf(fileID, ' \\addlinespace[3pt]\n');
        avg = mean(Table);
        fprintf(fileID, '\\textbf{Average} & ');
        fprintf(fileID, '%1.1f\\%%  & ', avg(1));
        fprintf(fileID, '%1.2f\\%% && ', avg(2));
        fprintf(fileID, '%1.1f\\%% & ', avg(3));
        fprintf(fileID, '%1.2f\\%% && ', avg(4));
        fprintf(fileID, '%1.1f\\%% & ', avg(5));
        fprintf(fileID, '%1.2f\\%% \\\\', avg(6));
            
        %%% TABLE CLOSING  %%%
        for i = 1:size(tableClosing)
            fprintf(fileID, '%s\n', char(tableClosing(i)));
        end

        fclose(fileID);
        
        delete Results_Baseline.mat Results_MC.mat