%------------------------------------------------------------------------------------------------%
%           This file reads the raw data from the WIOD and UNCTAD_TRAINS. 
%           It purges the data from trade imbalances and prepares the rebalanced
%           data from 'Main_Figure2.m', 'Main_Table1.m', and 'Main_Figure5.m'.
%------------------------------------------------------------------------------------------------%
%                        Description of Key Variables
% ------------------------------------------------------------------------------------------------
%     N: number of countries;  S: umber of industries  
%     A varibale with a name ending in "3D" correponds to a 3D cube with size N*N*S;  
%     Element Z(i,j,k) of a generic 3D cube Z, correponds to "origin i- destination j - industry k" 
%     sigma_k3D: industry-level CES parameter (sigma-1 ~ theta ~ trade elasticity)
%     tji_k3D: applied tariff rates (origin j-destination i-industry k) ---source: TRAINS, 2014
%     X_ji,k = expenditure level (origin j-destination i-industry k) --- source: WIOD 2014
%     See Section 5.1 for a detailed description of the data. 
% ------------------------------------------------------------------------------------------------

clear all
clc
cd '~/Master_Folder_Tariff_War'
 year = {'2000','2001', '2002', '2003', '2004', '2005', '2006' , '2007' ...
                    '2008','2009', '2010', '2011', '2012', '2013', '2014'};
       
%========================= Data for Baseline Model ========================
for   i=1:15
    
      file_name=strcat('./Data_Preparation_Files/WIOD_Data/WIOT',year{i},'.csv');
      DATA=dlmread(file_name,',');
      addpath('./Data_Preparation_Files/Baseline_Model')
      Step_01_Baseline
      Step_02_Baseline
      save(['./Cleaned_Data_Files/WIOT' year{i} '.mat'], 'N', 'S', 'Xijs_new3D', ...
                                                            'sigma_k3D', 'tjik_3D') 
end


%=========== Data for MC Model (Baseline + Markup Distortions) ============
clearvars -except year 
clc

for   i=1:15
        
      file_name=strcat('./Data_Preparation_Files/WIOD_Data/WIOT',year{i},'.csv');
      DATA=dlmread(file_name,',');
      addpath('./Data_Preparation_Files/MC_Model') 
      Step_01_MC
      Step_02_MC
      save(['./Cleaned_Data_Files/WIOT' year{i} '_MC.mat'], 'N', 'S', 'sigma_k3D', ...
                                                     'Xijs_new3D', 'mu_k3D', 'tjik_3D') 
end


%=============== Data for IO Model (Baseline + Input Trade) ===============
clearvars -except year 
clc

for   i=1:15
          
      file_name=strcat('./Data_Preparation_Files/WIOD_Data/WIOT',year{i},'.csv');
      DATA=dlmread(file_name,',');
      addpath('./Data_Preparation_Files/IO_Model')  
      Step_01_IO
      Step_02_IO
      save(['./Cleaned_Data_Files/WIOT' year{i} '_IO.mat'], 'N', 'S', 'Xjik3D',...
                                       'gamma_tilde', 'sigma_k3D', 'rev_share', 'tjik_3D') 
end


%======================= Data for Integrated Model ========================
clearvars -except year 
clc

for   i=1:15
         
      file_name=strcat('./Data_Preparation_Files/WIOD_Data/WIOT',year{i},'.csv');
      DATA=dlmread(file_name,',');
      addpath('./Data_Preparation_Files/Integrated_Model')  
      Step_01_Integrated
      Step_02_Integrated
      save(['./Cleaned_Data_Files/WIOT' year{i} '_Integrated.mat'], 'N', 'S', ...
                                'Xjik3D', 'gamma_tilde', 'sigma_k3D', 'rev_share', 'mu_k3D', 'tjik_3D') 
end