
%------------------------------------------------------------------------------------------------%
%                            This File Produces Figure 2
%------------------------------------------------------------------------------------------------%
%           Compute the cost of a global tariff war for each country year 
%           during the 2000-2014 period under different modeling specifications.
%------------------------------------------------------------------------------------------------%
%                        Description of Key Variables
% ------------------------------------------------------------------------------------------------
%   N: number of countries;  S: umber of industries  
%   A varibale with a name ending in "3D" correponds to a 3D cube with size N*N*S;  
%   Element Z(i,j,k) of 3D cude Z correponds to "origin i- destination j - industry k" 
%   sigma_k3D: industry-level CES parameter (sigma-1 ~ theta ~ trade elasticity)
%   tji_k3D: applied tariff rates (origin j-destination i-industry k) ---source: TRAINS, 2014
%   X_ji,k = expenditure level (origin j-destination i-industry k) --- source: WIOD 2014
%   See Section 5.1 for a detailed description of the data. 
% ------------------------------------------------------------------------------------------------
clear all
clc
cd '~/Master_Folder_Tariff_War'
year = {'2000','2001', '2002', '2003', '2004', '2005', '2006' , '2007' ...
                      '2008','2009', '2010', '2011', '2012', '2013', '2014'};
              
Cost_of_Tariff_War_Baseline=zeros(15,1);     Cost_of_Tariff_War_MC=zeros(15,1);
Cost_of_Tariff_War_IO=zeros(15,1);   Cost_of_Tariff_War_Integrated=zeros(15,1);

     
      for   i=1:15
       
     %========================= Baseline Model ========================           
        load(['./Cleaned_Data_Files/WIOT' year{i} '.mat'])  
        Xjik_3D = Xijs_new3D;
        lambda_jik3D=Xjik_3D./repmat(sum(Xjik_3D,1), [ N 1 1]) ; 
        Yi3D=repmat(sum(sum(Xjik_3D,1),3)', [ 1 N S]); Ri3D=repmat(sum(sum(Xjik_3D./(1+tjik_3D),2),3), [ 1 N S]) ;
        e_ik3D = repmat(sum(Xjik_3D,1), [ N 1 1])./ permute(Yi3D, [2 1 3]);      
        clearvars Lijs_new3D Yi_new3D sigma_s3D betajs3D Xijs_new3D;
       
        %----------- Compute the Counterfactual Nash Equilibrium -------------% 
        T0=[1.1*ones(N,1); 1.1*ones(N,1); 1.2*ones(N,1)];
        target = @(X) Trade_War_Baseline(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, tjik_3D);
        options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,'TolX',1e-14, 'algorithm','levenberg-marquardt'); 
        X_sol=fsolve(target,T0, options);
        %----------- Compute the Welfare Cost of Nash Tariffs -------------% 
        AUX0 = Welfare_Gains_Baseline(X_sol, N , S, e_ik3D, sigma_k3D, lambda_jik3D, tjik_3D);
        AUX1 = xlsread('./Cleaned_Data_Files/REAL_GDP_DATA.xlsx');
        REAL_GDP = AUX1((i-1)*44+1:i*44,4);
        Cost_of_Tariff_War_Baseline(i) = sum(0.01*AUX0.*REAL_GDP);
        
        
     %============  MC Model (Baseline + Markup Distortions) ============= 
        clearvars -except i Cost_of_Tariff_War_Baseline Cost_of_Tariff_War_MC ...
                             Cost_of_Tariff_War_IO Cost_of_Tariff_War_Integrated year; 
        load(['./Cleaned_Data_Files/WIOT' year{i} '_MC.mat'])
        Xjik3D= Xijs_new3D; Yi3D = repmat(sum(sum(Xjik3D,1),3)', [1 N S]);
        lambda_jik3D = Xjik3D./repmat(sum(Xjik3D,1), [N 1 1]);
        e_ik3D= repmat(sum(Xjik3D,1), [N 1 1])./permute(Yi3D, [2 1 3]);
        Ri3D=repmat(sum(sum(Xjik3D./((1+tjik_3D).*(1+mu_k3D)),2),3), [ 1 N S]) ;      
        clearvars Lijs_new3D Yi_new3D sigma_s3D betajs3D Xijs_new3D;
        
        %----------- Compute the Counterfactual Nash Equilibrium -------------% 
        T0=[1.15*ones(N,1); 1.15*ones(N,1); 1.2*ones(N*S,1)];
        target = @(X) Trade_War_MC(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, mu_k3D, tjik_3D);
        options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,'TolX',1e-14, 'algorithm','levenberg-marquardt'); 
        X_sol=fsolve(target,T0, options);
        %----------- Compute the Welfare Cost of Nash Tariffs -------------% 
        AUX0 = Welfare_Gains_MC(X_sol, N , S, e_ik3D, sigma_k3D, lambda_jik3D, tjik_3D);
        AUX1 = xlsread('./Cleaned_Data_Files/REAL_GDP_DATA.xlsx');
        REAL_GDP = AUX1((i-1)*44+1:i*44,4);
        Cost_of_Tariff_War_MC(i) = sum(0.01*AUX0.*REAL_GDP);
        
        
    %================= IO Model (Baseline + Input Trade) ================= 
        clearvars -except i Cost_of_Tariff_War_Baseline Cost_of_Tariff_War_MC ...
                             Cost_of_Tariff_War_IO Cost_of_Tariff_War_Integrated year; 
        load(['./Cleaned_Data_Files/WIOT' year{i} '_IO.mat'])
        rev_share = permute(reshape(gamma_tilde',N,N,S),[2 1 3]);
        AUX0 = rev_share .* repmat(sum(Xjik3D./(1+tjik_3D), 2), [1 N, 1]);
        Ri3D=repmat(sum(sum(AUX0, 1),3)', [1 N S]);
        Yi3D=repmat(sum(sum(Xjik3D, 1),3)', [1 N S]);
        lambda_jik3D = Xjik3D./repmat(sum(Xjik3D,1), [N 1 1]);
        e_ik3D = repmat(sum(Xjik3D,1), [N 1 1])./repmat(sum(sum(Xjik3D,1),3), [N 1 S]);

        %----------- Compute the Counterfactual Nash Equilibrium -------------%
        T0=[1.1*ones(N,1); 1.1*ones(N,1); 1.2*ones(N,1)];
        target = @(X) Trade_War_IO(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, gamma_tilde, rev_share, tjik_3D);
        options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,'TolX',1e-14, 'algorithm','levenberg-marquardt'); % , 'algorithm','levenberg-marquardt' 'trust-region-reflective'
        X_sol=fsolve(target,T0, options);
        %----------- Compute the Welfare Cost of Nash Tariffs -------------% 
        AUX0 =  Welfare_Gains_IO(X_sol, N , S, e_ik3D, sigma_k3D, lambda_jik3D, gamma_tilde, tjik_3D);
        AUX1 = xlsread('./Cleaned_Data_Files/REAL_GDP_DATA.xlsx');
        REAL_GDP = AUX1((i-1)*44+1:i*44,4);
        Cost_of_Tariff_War_IO(i) = sum(0.01*AUX0.*REAL_GDP);
         
        
        %======================= Integrated Model ========================
        clearvars -except i Cost_of_Tariff_War_Baseline Cost_of_Tariff_War_MC ...
                             Cost_of_Tariff_War_IO Cost_of_Tariff_War_Integrated year; 
        load(['./Cleaned_Data_Files/WIOT' year{i} '_Integrated.mat'])
        rev_share = permute(reshape(gamma_tilde',N,N,S),[2 1 3]);
        AUX0 = rev_share .* repmat(sum(Xjik3D./((1+tjik_3D).*(1+mu_k3D)), 2), [1 N, 1]);
        Ri3D=repmat(sum(sum(AUX0, 1),3)', [1 N S]);
        Yi3D=repmat(sum(sum(Xjik3D, 1),3)', [1 N S]);
        lambda_jik3D = Xjik3D./repmat(sum(Xjik3D,1), [N 1 1]);
        e_ik3D = repmat(sum(Xjik3D,1), [N 1 1])./repmat(sum(sum(Xjik3D,1),3), [N 1 S]); 
        
        %----------- Compute the Counterfactual Nash Equilibrium -------------%
        T0=[1.1*ones(N,1); 1.1*ones(N,1); 1.5*ones(N,1); 1.2*ones(N,1); 1.1*ones(N*S,1)];
        target = @(X) Trade_War_Integrated(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, mu_k3D, gamma_tilde, rev_share, tjik_3D);
        options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,'TolX',1e-14, 'algorithm','levenberg-marquardt'); % , 'algorithm','levenberg-marquardt' 'trust-region-reflective'
        X_sol=fsolve(target,T0, options);
        %----------- Compute the Welfare Cost of Nash Tariffs -------------% 
        AUX0 =  Welfare_Gains_Integrated(X_sol, N , S, e_ik3D, sigma_k3D, lambda_jik3D, gamma_tilde, tjik_3D, mu_k3D, rev_share);
        AUX1 = xlsread('./Cleaned_Data_Files/REAL_GDP_DATA.xlsx');
        REAL_GDP = AUX1((i-1)*44+1:i*44,4);
        Cost_of_Tariff_War_Integrated(i) = sum(0.01*AUX0.*REAL_GDP);
        
      end
      
      
%--------------------------------------------------------------------------------------
%                               Print Output
%--------------------------------------------------------------------------------------    
    line([2000:2014]', -Cost_of_Tariff_War_Integrated/1000,'Color','b','LineWidth',3.4, 'linestyle','-.') 
    line([2000:2014]', -Cost_of_Tariff_War_IO/1000,'Color','k','LineWidth',3.4, 'linestyle','--')
    line([2000:2014]', -Cost_of_Tariff_War_MC/1000,'Color','r','LineWidth',3)
    line([2000:2014]', -Cost_of_Tariff_War_Baseline/1000,'Color','[0.6 0.6 0.6]','LineWidth',3, 'linestyle',':')
    xlabel('\textbf{year}','interpreter','latex','FontSize',16);
    ylabel('\textbf{ Welfare Cost (billion \$)}','interpreter','latex','FontSize',16);
    legend({'Baseline + Markup Distortions + Input trade','Baseline + Input trade', ...
            'Baseline + Markup Distortions','Baseline Model'}, ...
            'Location','NorthWest', 'FontSize',14, 'interpreter','latex');
    legend boxoff 
    print -depsc2 Figure_2.eps

% -------------------------------------------------------------------------------------
    line([2000:2014]', -Cost_of_Tariff_War_Integrated/1000,'Color','b','LineWidth',3.4, 'linestyle','-.')
    line([2000:2014]', -Cost_of_Tariff_War_IO/1000,'Color','k','LineWidth',3.4, 'linestyle','--')
    line([2000:2014]', -Cost_of_Tariff_War_MC/1000,'Color','r','LineWidth',3)
    line([2000:2014]', -Cost_of_Tariff_War_Baseline/1000,'Color','[0.6 0.6 0.6]','LineWidth',3, 'linestyle',':')
    xlabel('\textbf{Year}','interpreter','latex','FontSize',16);
    ylabel('\textbf{ Welfare Cost (billion \$)}','interpreter','latex','FontSize',16);
    legend({'Baseline + Markup Distortions + Input trade','Baseline + Input trade', ...
            'Baseline + Markup Distortions','Baseline Model'}, ...
            'Location','NorthWest', 'FontSize',14, 'interpreter','latex'); 
    legend boxoff 
    print -dpng Figure_2.png
    
 %--------------------------------------------------------------------------------------

  
    
