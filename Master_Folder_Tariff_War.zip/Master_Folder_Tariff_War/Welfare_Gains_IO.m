function [Gains]=Welfare_Gains_IO(X, N , S, e_ik3D, sigma_k3D, lambda_jik3D, gamma_tilde, tjik_3D_app)
% report changes in relative wages wi_h, in real wages (term with lambda_jj,s),changes in k_j , and changes in welfare.

wi_h=abs(X(1:N));    % abs(.) is used avoid complex numbers...
Ei_h=abs(X(N+1:N+N));

% Construct 3D cube of Nash tariffs
 tjik = abs(X(N+N+1:end));
 tjik_2D = repmat(tjik', N, 1);
 tjik_3D = repmat(eye(N) + tjik_2D.*(eye(N)==0), [1 1 S]) -1 ;
 tjik_h3D = (1+tjik_3D)./(1+tjik_3D_app);
 fprintf('Average Nash tariff under the IO model = %0.2f%% \n',100*mean(tjik_3D(:)) )   

% Calculate the change in unit cost
AUX7 = exp(sum(gamma_tilde.*log(repmat(wi_h',N*S,1)),2)); 
ci_h3D = repmat(reshape(AUX7,N,1,S), 1 ,N);

% Calculate the change in price indexes
AUX9 = lambda_jik3D.*( (tjik_h3D.* ci_h3D ).^(1-sigma_k3D) );
Pi_h = exp(sum((e_ik3D(1,:,:)./(1-sigma_k3D(1,:,:))).*log(sum(AUX9,1)),3))';

% Calculate the change in welfare
Wi_h = Ei_h./Pi_h;
Gains = 100*(Wi_h-1);
end