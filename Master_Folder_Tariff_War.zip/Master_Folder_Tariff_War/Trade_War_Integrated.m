function [ceq] = Trade_War_Integrated(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, mu_k3D, gamma_tilde, rev_share, tjik_3D_app)

% ------------------------------------------------------------------
%        Description of Inputs
% ------------------------------------------------------------------
%   N: number of countries;  S: umber of industries 
%   Yi3D: national expenditure ~ national income
%   Ri3D: national wage revneues ~ sales net of tariffs  
%   e_ik3D: industry-level expenditure share (C-D weight)
%   lambda_jik: within-industry expenditure share
%   sigma: industry-level CES parameter (sigma-1 ~ trade elasticity)
%   mu: industry-level markup
%   gamma_tilde: origin-specific labor share in the reformulated IO model
%   tjik_3D_app: applied tariff
% ------------------------------------------------------------------

wi_h=abs(X(1:N));    % abs(.) is used avoid complex numbers...
Yi_h=abs(X(N+1:N+N));

% construct 3D cubes from 1D vectors
Yi_h3D=repmat(Yi_h,[1 N S]);
Yj_h3D=permute(Yi_h3D,[2 1 3]);
Yj3D=permute(Yi3D,[2 1 3]);


%---- construct 3D cubes for change in tariffs ---------------
 tau = abs(X(N+N+1:N+N+N));
 mu_avg = abs(X(N+N+N+1:N+N+N+N));
 Multiplier = abs(X(N+N+N+N+1:end));
 rho = permute(rev_share, [2 1 3]).*(1 - (repmat(mu_avg',[N 1 S])./(1 + mu_k3D)));
 tjik =  kron(Multiplier, ones(N-1,1)).*(1 + repmat(kron(tau,ones(N-1,1)),S,1) - rho(repmat(eye(N),[1 1 S])==0)) - 1;
 tjik_3D = zeros(N,N,S);
 tjik_3D(repmat(eye(N), [ 1 1 S])==0) = tjik;
 tjik_h3D = (1+tjik_3D)./(1+tjik_3D_app);

% ------------------------------------------------------------------
%        Wage Income = Total Sales net of Taxes (Equation 22)
% ------------------------------------------------------------------
AUX7 = exp(sum(gamma_tilde.*log(repmat(wi_h',N*S,1)),2)); 
ci_h3D = repmat(reshape(AUX7,N,1,S), 1 ,N);
AUX9 = lambda_jik3D.*( (tjik_h3D.* ci_h3D ).^(1-sigma_k3D) );
AUX10 = repmat(sum(AUX9,1),[N 1 1]);
AUX11 = AUX9./AUX10;
AUX12 = AUX11.*e_ik3D.*(Yj_h3D.*Yj3D)./(1+tjik_3D);
total_rev = repmat(sum(AUX12./(1+mu_k3D),2), [1 N 1]).*rev_share;
wage_rev = sum(sum(total_rev,3),1)';

ERR1 = wage_rev - wi_h.*Ri3D(:,1,1);
ERR1(N,1) = sum(Ri3D(:,1,1).*(wi_h-1));  % replace one excess equation with normalization,w^=w'/w=1, where w=sum_i(wi'*Li)/sum(wi*Li)

% ------------------------------------------------------------------
%        Total Income = Total Sales (Equation 21)
% ------------------------------------------------------------------
Pi_k = repmat(sum(mu_k3D.*AUX12./(1+mu_k3D),2), [1 N 1]).*rev_share;
Profit = sum(sum(Pi_k,3),1)';
AUX13 = ( tjik_3D./(1+tjik_3D)).* AUX11 .* e_ik3D .* Yj_h3D.*Yj3D;
ERR2 = Profit + sum(sum(AUX13,3),1)' + wi_h.*Ri3D(:,1,1) - Yi_h.*Yi3D(:,1,1);

% ------------------------------------------------------------------
%            Optimal Tariff Formula (Equation 25)
% ------------------------------------------------------------------    
AUX5 = repmat( reshape(rev_share(repmat(eye(N)==1, [1 1 S])), N,1,S), [1 N 1]);
delta=zeros(N,N,S);

for i=1:S
    delta(:,:,i) = (rev_share(:,:,i)'./AUX5(:,:,i))*AUX11(:,:,i);
end

AUX6 = AUX5.*AUX12.*repmat(1-eye(N),[1 1 S]) ;
ERR3 = mu_avg - (1 +  Profit./(wi_h.*Ri3D(:,1,1)));
mu_avg_3D =  repmat(mu_avg', [N 1 S]);

AUX7 = ( AUX6.*( sigma_k3D - 1 ).*(1-delta) ) ./ repmat(sum(sum(AUX6,2),3), [1 1 S]) ;
ERR4 = tau - (1 ./sum(sum(AUX7,2),3));

AUX8 = mu_avg_3D./ (1 + mu_k3D); 
AUX9 =  (1 + ( sigma_k3D - 1 ).*AUX11)./   (1 + (1 - AUX5.*(1 - AUX8)).*( sigma_k3D - 1 ).*AUX11 );
ERR5 = Multiplier - AUX9(repmat(eye(N),[1 1 S])==1);
% ------------------------------------------------------------------

ceq= [ERR1' ERR2' ERR3' ERR4' ERR5'];

end
