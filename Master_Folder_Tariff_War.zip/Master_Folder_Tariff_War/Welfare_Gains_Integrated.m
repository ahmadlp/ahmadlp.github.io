function [Gains]=Welfare_Gains_Integrated(X, N , S, e_ik3D, sigma_k3D,  lambda_jik3D, gamma_tilde, tjik_3D_app, mu_k3D, rev_share)

wi_h=abs(X(1:N));    % abs(.) is used avoid complex numbers...
Ei_h=abs(X(N+1:N+N));

 % Construct 3D cube of Nash tariffs
 tau = abs(X(N+N+1:N+N+N));
 mu_avg = abs(X(N+N+N+1:N+N+N+N));
 Multiplier = abs(X(N+N+N+N+1:end));
 rho = permute(rev_share, [2 1 3]).*(1 - (mu_avg./(1 + mu_k3D)));
 tjik =  kron(Multiplier, ones(N-1,1)).*(1 + repmat(kron(tau,ones(N-1,1)),S,1) - rho(repmat(eye(N),[1 1 S])==0)) - 1;
 tjik_3D = zeros(N,N,S);
 tjik_3D(repmat(eye(N), [ 1 1 S])==0) = tjik;
 tjik_h3D = (1+tjik_3D)./(1+tjik_3D_app);
 fprintf('Average Nash tariff under the integrated model = %0.2f%% \n',100*mean(tjik_3D(:)) )  

% Calculate the change in unit cost 
AUX7 = exp(sum(gamma_tilde.*log(repmat(wi_h',N*S,1)),2)); %%%.* exp(sum(a2.*log(repmat((1+tjik)',N*S,1)),2));
ci_h3D = repmat(reshape(AUX7,N,1,S), 1 ,N);

% Calculate the change in price indexes
AUX9 = lambda_jik3D.*( (tjik_h3D.* ci_h3D ).^(1-sigma_k3D) );
Pi_h = exp(sum((e_ik3D(1,:,:)./(1-sigma_k3D(1,:,:))).*log(sum(AUX9,1)),3))';

% Calculate the change in welfare
Wi_h = Ei_h./Pi_h;
Gains = 100*(Wi_h-1);
end