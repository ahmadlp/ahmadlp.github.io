%------------------------------------------------------------------------------------------------%
%                            This File Produces Figure 5
%------------------------------------------------------------------------------------------------%
%           Compute the cost of global tariff cooperation for each year country
%            during the 2000-2014 period under markup distortions.
%------------------------------------------------------------------------------------------------%
%                        Description of Key Variables
% ------------------------------------------------------------------------------------------------
%   N: number of countries;  S: umber of industries  
%   A varibale with a name ending in "3D" correponds to a 3D cube with size N*N*S;  
%   Element Z(i,j,k) of 3D cude Z correponds to "origin i- destination j - industry k" 
%   sigma_k3D: industry-level CES parameter (sigma-1 ~ theta ~ trade elasticity)
%   tji_k3D: applied tariff rates (origin j-destination i-industry k) ---source: TRAINS, 2014
%   X_ji,k = expenditure level (origin j-destination i-industry k) --- source: WIOD 2014
%   See Section 5.1 for a detailed description of the data. 
% ------------------------------------------------------------------------------------------------
    clear all
    clc
    cd '~/Master_Folder_Tariff_War'
    year = {'2000','2001', '2002', '2003', '2004', '2005', '2006' , '2007' ...
                          '2008','2009', '2010', '2011', '2012', '2013', '2014'};

    Gains_from_Cooperation=zeros(15,1);
       

        for i=1:15
        clearvars -except i Gains_from_Cooperation year; 
                load(['./Cleaned_Data_Files/WIOT' year{i} '_MC.mat'])
                Xjik3D= Xijs_new3D; Yi3D = repmat(sum(sum(Xjik3D,1),3)', [1 N S]);
                lambda_jik3D = Xjik3D./repmat(sum(Xjik3D,1), [N 1 1]);
                e_ik3D= repmat(sum(Xjik3D,1), [N 1 1])./permute(Yi3D, [2 1 3]);
                Ri3D=repmat(sum(sum(Xjik3D./((1+tjik_3D).*(1+mu_k3D)),2),3), [ 1 N S]) ;
                clearvars Xijs_new3D;
                
                %----------- Compute the Counterfactual Cooperative Equilibrium -------------% 
                T0=[1.1*ones(N,1); 1.1*ones(N,1); 1.5*ones(N*S,1); 1.1];
                target = @(X) Cooperative(X, N ,S, Yi3D, Ri3D, e_ik3D, sigma_k3D, lambda_jik3D, mu_k3D, tjik_3D);
                options = optimset('Display','iter','MaxFunEvals',inf,'MaxIter',inf,'TolFun',1e-12,...
                                                                'TolX',1e-14, 'algorithm','levenberg-marquardt');
                X_sol=fsolve(target,T0, options);
                
                %----------- Compute the Gains from Cooperative Tariffs -------------% 
                AUX0 = Welfare_Gains_MC(X_sol(1:end-1), N , S, e_ik3D, sigma_k3D, lambda_jik3D, tjik_3D);
                AUX1 = xlsread('~/OneDrive - Indiana University/Box Sync/Trade War/REAL_GDP_DATA.xlsx');
                REAL_GDP = AUX1((i-1)*44+1:i*44,4);
                Gains_from_Cooperation(i) = sum(0.01*AUX0.*REAL_GDP);


        end

%------------------------------------------------------------------------------------------------
%                             Print Output (eps and png formats)
%------------------------------------------------------------------------------------------------    
    line([2000:2014]', Gains_from_Cooperation/1000,'Color','k','LineWidth',3.4, 'linestyle','--')
   
    xlabel('\textbf{year}','interpreter','latex','FontSize',16);
    ylabel('\textbf{ Welfare Gains (billion \$)}','interpreter','latex','FontSize',16);
    legend off 
    print -depsc2 Figure_5.eps
    
 %------------------------------------------------------------------------------------------------    
    line([2000:2014]', Gains_from_Cooperation/1000,'Color','k','LineWidth',3.4, 'linestyle','--')
   
    xlabel('\textbf{year}','interpreter','latex','FontSize',16);
    ylabel('\textbf{ Welfare Gains (billion \$)}','interpreter','latex','FontSize',16);
    legend off
    print -dpng Figure_5.png
%-------------------------------------------------------------------------------------------------- 
 
