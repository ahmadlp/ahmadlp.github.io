function [tau, T, x, theta, mu_i, real_wage] = post_est_main(X,s);

global N Z w L A y

d= X(1) * (s.dist.^X(2)).* (X(3).^s.border) .* (X(4).^s.lang).* (X(5).^s.tr_agr);
tau = reshape(d,N,N); tau(tau<1)=1; tau((eye(N)==1))=1;
ratio=X(6);  

ei = [X(7:N+6) 1-X(7:N+6)]; e_iz = repmat(ei,N,1);
theta_h = 4/(0.5 + 0.5*ratio); theta_l=4/(0.5/ratio + 0.5);
theta=[theta_h  theta_l];
theta_q1=kron(theta,ones(N,N));  %(N,N*Z)


T=kron(A,ones(1,N*Z)); W=repmat(w,1,N); mc=tau.*W; 
price=repmat(mc,1,Z);

eps=1; reps=0; mu=1;

while (eps>1e-12) && (reps<600)
   

        p = T.* (price.^-theta_q1);
        PQ=sum(p); %(N*Z,1)  
        Pv=kron(ones(N,1),PQ); %Pv is (N,N*Z)
 
        pi_ji= (p./Pv) .* e_iz;
        x = abs(pi_ji) .* y ;
       
        
        x_h = x(:,1:N); x_l=x(:,N+1:Z*N);
        e_h = sum(x_h(:))/sum(x(:)); e_l = sum(x_l(:))/sum(x(:));
        theta_l = 4/(e_l + e_h*ratio); theta_h=4/(e_l/ratio + e_h);
        theta=[theta_h  theta_l];
        theta_q1=kron(theta,ones(N,N));  %(N,N*Z)
        w_model=sum(x,2)./L;
        
eps = max( abs(w-w_model) );

A=A.*(w./w_model).^mu; A=A/A(1);
T=kron(A,ones(1,N*Z));
reps=reps+1;


end

trade = x .* repmat(1-eye(N),1,Z);
sigma_H = 1 + theta_h/2.46; sigma_L = 1 + theta_l/2.46;
markup=[sigma_H/(sigma_H-1)  sigma_L/(sigma_L-1)];
markup_q1=kron(markup,ones(N,N));  %(N,N*Z)
mu_i = sum(markup_q1.*trade,2)./sum(trade,2);

AUX1=repmat([1:N]',Z,1);
Price_index = exp( accumarray(AUX1, ei'.*log(PQ')));
real_wage= w_model./Price_index;

disp([ 'outer loop error= ', num2str(eps)])






