
clear all;
clc;
cd '~/Replication File/Country-Level Estimation/'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%   Read The Data     %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Data = xlsread('~/Replication File/Country-Level Estimation/Data_Trade_100.xlsx'); 

global N Z w L A y;

s.tr_flow = Data(:,1);      % trade flows
s.igdp = Data(:,2);         % importer gdp
s.egdp = Data(:,4);         % exporter gdp
s.dist = Data(:,6)/1000;    % distance in thousand km
s.border = Data(:,7);       % dummy of common border
s.lang = Data(:,8);         % dummy of common language
s.tr_agr = Data(:,9);       % dummy for being in a trade agreement

N=100; Z=2;
w=Data(1:N,2)./Data(1:N,3);   
w_US=w(1); w=w/w_US;  % Nx1 vector of wage ~ income p/c
L=Data(1:N,3);  % Nx1 vector of population 
y=repmat((w.*L)',N,Z); A=L/L(1);

s.tr_flow=s.tr_flow/w_US; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Run The Main Estimation  %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This step solves for X=[beta, rho, e], which is composed of 106 parameters
% The vector of exporter fixed effects are solved for within the 'objective' function

%load('theta.mat'); X0=X_main;   
X0 =      [4.5     0.3        0.8      0.8  0.8        0.5             w'./max(w)  ];
UB =      [ 8      1           1       1      1         1              ones(1,N)   ];
LB =      [ 1      0          0.5     0.5    0.5       0.1             0*ones(1,N) ];

options = optimset('Display','Iter','MaxFunEvals',40000,'MaxIter',100,'TolFun',1e-8,'TolX',1e-8);

[X_main, fval, ~,~,~,~, J ]=lsqnonlin(@(X) objective(X,s),X0,LB,UB,options);
%[omega, fval, ~,~,~,~, J ]=fmincon(@(X) objective(X,s),X0, [],[],[],[],LB,UB,[],options); 

save('theta.mat', 'X_main');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Display Results   (Column 2 in Table 8)  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
non_zero=(s.tr_flow>0);
share_data_all = log(s.tr_flow);
share_data=share_data_all(non_zero);
r2_main= 1 - fval / sum( ( share_data - mean(share_data) ).^2 );
Hessian=abs(J')* abs(J);
std_err_main = sqrt(diag(inv(Hessian)));

disp('rho      beta_const   beta_dist  beta_border   beta_lang  beta_agr ')
disp(num2str([X_main(6) X_main(1:5)]))
disp([num2str(std_err_main(6)) '  ' num2str(std_err_main(1:5)')])
disp(['R-squared = ',num2str(r2_main)])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Display In-Sample Fit (Fig 1 in Section Section 5) %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[ tau, T, x, theta, markup, real_wage] = post_est_main(X_main,s);
 
AUX=repmat([1:N*N]',Z,1); 
x_temp=accumarray(AUX,reshape(x,N*N*Z,1));  
x_model=reshape(reshape(x_temp,N,N)',N*N,1); 
share_model=log(x_model(non_zero));
scatter(share_data,share_model)
hold on
line(share_data,share_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Compute the Contribution of Specialization-Driven Scale Effects to TFP Differences  (Section 5.3) %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ri_H=sum(x(:,1:N),2)./sum(x,2); ri_L = 1 - ri_H;
theta_k = 4; gamma_k = 2.46; %%% the choice of gamma is from EKK2011
eps_H = 1 + theta(1)/gamma_k ; eps_L = 1 + theta(2)/gamma_k ;
ell_i = L./(ri_H*eps_H + ri_L*eps_L);
Scale_overall = ell_i.^(X_main(7:N+6)'/theta(1) + (1-X_main(7:N+6)')/theta(2));

Scale_size_driven=( L./(1 + theta_k/gamma_k)).^(1/theta_k);

disp(['Contribution of Specialization-Driven Scale Effects =', num2str( 100*(1 - var(log(real_wage.*(Scale_size_driven./Scale_overall))) / var(log(real_wage))) ) '%'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%    STANDARD GRAVITY MODEL  (Column 1 in Table 8) %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X0 =      [2.5     0.4        0.8      0.8     0.8    ];
UB =      [ 8      1           1       1        1     ];
LB =      [ 1      0          0.5     0.5      0.5    ];

options = optimset('Display','Iter','MaxFunEvals',40000,'MaxIter',100,'TolFun',1e-8,'TolX',1e-8);

[X_std, fval_std, ~,~,~,~, J_std ]=lsqnonlin(@(X) objective_std(X,s),X0,LB,UB,options);

r2_std= 1 - fval_std / sum( ( share_data - mean(share_data) ).^2 );
Hessian=abs(J_std')* abs(J_std);
std_err_std = sqrt(diag(inv(Hessian)));

disp('beta_const  beta_dist  beta_border  beta_lang  beta_agr ')
disp(num2str(X_std))
disp(num2str(std_err_std'))
disp(['R-squared = ',num2str(r2_std)])
