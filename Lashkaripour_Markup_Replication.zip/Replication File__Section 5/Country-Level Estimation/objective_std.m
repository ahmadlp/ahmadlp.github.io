function [resid] = objective_std(X,s);
% This Function Assumes sigma=1 and estimates IM fixed effects
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global N w L A y

%disp(['X = ', num2str(X(1:6))])
d= X(1) * (s.dist.^X(2)).* (X(3).^s.border) .* (X(4).^s.lang).* (X(5).^s.tr_agr);
tau = reshape(d,N,N); tau(tau<1)=1; tau((eye(N)==1))=1;

theta=4; Z=1;
theta_q1=kron(theta,ones(N,N));  %(N,N*Z)

T=kron(A,ones(1,N*Z)); W=repmat(w,1,N); mc=tau.*W; 
price=repmat(mc,1,Z);

eps1=1; reps=0; mu=1;

while (eps1>1e-12) && (reps<600)
   

        p = T.* (price.^-theta_q1);
        PQ=sum(p); %(N*Z,1)  
        Pv=kron(ones(N,1),PQ); %Pv is (N,N*Z)
 
        pi_ji= (p./Pv);
        x = abs(pi_ji) .* y(:,1:N) ;
        w_model=sum(x,2)./L;
        
eps1 = max( abs(w-w_model) );

A=A.*(w./w_model).^mu; A=abs(A)/abs(A(1));
T=kron(A,ones(1,N*Z));
reps=reps+1;
end

AUX2=repmat([1:N*N]',Z,1); 
x_temp=accumarray(AUX2,reshape(x,N*N*Z,1));  
x_model=reshape(reshape(x_temp,N,N)',N*N,1);  
non_zero=(s.tr_flow>0);

share_model_all= log(x_model);
share_model=share_model_all(non_zero);

share_data_all = log(s.tr_flow);
share_data=share_data_all(non_zero);

%disp(['inner loop error= ', num2str(epsilon),', outer loop error= ', num2str(eps1)])

%resid =  sum( ( share_data - share_model ) .^ 2 );  %to use with fmincon
resid =  (share_data - share_model); %to use with lsqnonlin




