function [resid] = objective(X,s);

global N Z w L A y

rho=X(6);
d= X(1) * (s.dist.^X(2)).* (X(3).^s.border) .* (X(4).^s.lang).* (X(5).^s.tr_agr);
tau_ji = reshape(d,N,N); tau_ji(tau_ji<1)=1; tau_ji((eye(N)==1))=1;
  
ei = [X(7:N+6) 1-X(7:N+6)]; e_iz = repmat(ei,N,1);

%%% assign initial values to theta_H and theta_L %%%%%%%%%
theta_H = 4/(0.5 + 0.5*rho); theta_L=4/(0.5/rho + 0.5);
theta=[theta_H  theta_L];
theta_q1=kron(theta,ones(N,N));  %(N,N*Z)

%%%% the following loop computes the exporter fixed effect Ti %%%%%%%%%%%%%
Ti=kron(A,ones(1,N*Z)); W=repmat(w,1,N); 
price=repmat(tau_ji.*W,1,Z);
eps1=1; reps=0; mu=1;

while (eps1>1e-12) && (reps<600)
    
   %%%% calculated trade flows using the gravity equation %%%%
        p = Ti.* (price.^-theta_q1);
        PQ=sum(p); %(N*Z,1)  
        Pv=kron(ones(N,1),PQ); %Pv is (N,N*Z)
 
        pi_ji= (p./Pv) .* e_iz;
        x_ji = abs(pi_ji) .* y ; 
   
   %%%%% Update theta_H and theta_L accoring to R4 %%%%%%%%%%%%
        x_jiH = x_ji(:,1:N); x_jiL = x_ji(:,N+1:Z*N);
        e_H = sum(x_jiH(:))/sum(x_ji(:)); e_L = sum(x_jiL(:))/sum(x_ji(:));
        theta_L = 4/(e_L + e_H*rho); theta_H=4/(e_L/rho + e_H);
        theta=[theta_H  theta_L];
        theta_q1=kron(theta,ones(N,N));  %(N,N*Z)
        
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        w_model=sum(x_ji,2)./L;
        eps1 = max( abs(w-w_model) );

        A=A.*(w./w_model).^mu; A=abs(A)/abs(A(1));
        Ti=kron(A,ones(1,N*Z));
        reps=reps+1;
        
end

AUX2=repmat([1:N*N]',Z,1); 
x_temp=accumarray(AUX2,reshape(x_ji,N*N*Z,1));  
x_model=reshape(reshape(x_temp,N,N)',N*N,1);  
non_zero=(s.tr_flow>0);

lnX_model_all= log(x_model);
lnX_model=lnX_model_all(non_zero);

lnX_data_all = log(s.tr_flow);
lnX_data=lnX_data_all(non_zero);

%disp(['inner loop error= ', num2str(epsilon),', outer loop error= ', num2str(eps1)])

%resid =  sum( ( lnX_data - lnX_model ) .^ 2 );  %to use with fmincon
resid =  (lnX_data - lnX_model); %to use with lsqnonlin




