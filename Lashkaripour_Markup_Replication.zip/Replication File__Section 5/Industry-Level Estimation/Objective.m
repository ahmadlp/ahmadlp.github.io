function [resid]= Objective(X, xji, w, Y, theta, dist, border, lang, alpha, L);

global N 

rho=X(1);
%%% assign an initial value to theta_L and theta_H %%%
theta_H = theta./(0.5 + 0.5/rho); 
theta_L = theta./(0.5 + 0.5*rho);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tau_jik =  X(2) * (dist.^X(3)) .* (X(4).^border) .* (X(5).^lang); tau_jik(eye(N)==1)=1;
e_ik = X(6:N+5); 

%%% the following loop computes the exporter fixed effects %%%
Ti=w(:,1); %% initial guess: T_ik = w_i
eps=1; reps=0;

while (eps>1e-14) && (reps<1000)

%%% Calculate trade shares using the gravity eq. %%%%    
T=repmat(Ti,1,N);

delta_H = T .* ( (tau_jik .* w ) .^ -theta_H );
lambdaji_H= delta_H ./ repmat(sum(delta_H),N,1);

delta_L = T .* ( (tau_jik .* w ) .^ -theta_L );
lambdaji_L= delta_L ./ repmat(sum(delta_L),N,1);

%%% Calculate industry-level trade values %%%%
e_iH = repmat(e_ik, N,1);
e_iL = 1 - e_iH;

xji_L_model = lambdaji_L .* e_iL.*alpha.*Y; xji_H_model= lambdaji_H .* e_iH.*alpha.*Y;
xji_model = xji_H_model + xji_L_model;

w_model = sum(xji_model ,2)./L(:,1);
eps = max(abs(w(:,1) - w_model));

Ti=Ti.*(w(:,1)./w_model).^1;
Ti=abs(Ti)/abs(Ti(1));
reps = reps + 1 ;

%%% Calculate theta_z according to R4 %%%%
e_H = sum(xji_H_model(:))/sum(xji_model(:)); e_L = sum(xji_L_model(:))/sum(xji_model(:));
theta_H = theta./(e_H + e_L/rho); 
theta_L = theta./(e_L + e_H.*rho);

end

xji_data_1D = reshape(xji,N*N,1); id=xji_data_1D>0;
xji_model_1D = reshape(xji_model,N*N,1);

%%%% Fit Trade Shares %%%%%%%%
% resid = (log(lambdaji_model_1D(id)) -  log(lambdaji_1D(id)) );
% denom = ( log(lambdaji(id)) - mean(log(lambdaji(id))) ).^2 ;
% resid = resid/(sum(denom(:))^0.5);

%%%% Fit Trade Vaues %%%%%%%%%%
resid = (log(xji_model_1D(id)) -  log(xji_data_1D(id)) );
denom = ( log(xji(id)) - mean(log(xji(id))) ).^2 ;
resid = resid/(sum(denom(:))^0.5);

end