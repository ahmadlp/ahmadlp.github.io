function [gains, gains_std]= Post_Estimation(X, xji, w, Y, theta, dist, border, lang, alpha, r, L);

global N 

rho=X(1);
theta_H = theta./(0.5 + 0.5/rho); 
theta_L = theta./(0.5 + 0.5*rho);
tau =  X(2) * (dist.^X(3)) .* (X(4).^border) .* (X(5).^lang); tau(eye(N)==1)=1;
ei = X(6:N+5); 
Ti=w(:,1);

eps=1; reps=0;

while (eps>1e-12) && (reps<600)

T=repmat(Ti,1,N);

delta_H = T.* ( (tau .* w ) .^ -theta_H );
lambdaji_H= delta_H ./ repmat(sum(delta_H),N,1);

delta_L = T.* ( (tau .* w ) .^ -theta_L );
lambdaji_L= delta_L ./ repmat(sum(delta_L),N,1);

ei_H = repmat(ei, N,1);
ei_L = 1 - ei_H;

xji_L_model = lambdaji_L .* ei_L.*alpha.*Y; xji_H_model= lambdaji_H .* ei_H.*alpha.*Y;
xji_model = xji_H_model + xji_L_model;

w_model = sum(xji_model ,2)./L(:,1);

eps = max(abs(w(:,1) - w_model));

Ti=Ti.*(w(:,1)./w_model).^1;

reps = reps +1 ;

e_H = sum(xji_H_model(:))/sum(xji_model(:)); e_L = sum(xji_L_model(:))/sum(xji_model(:));
theta_H = theta./(e_H + e_L/rho); 
theta_L = theta./(e_L + e_H.*rho);

end

disp(['[theta_H theta_L]', num2str([theta_H(1,1) theta_L(1,1)])])
ri_H = sum(xji_H_model,2)./sum(xji_model,2); ri_L =  sum(xji_L_model,2)./sum(xji_model,2);
bi_H = sum(xji_H_model)'./sum(xji_model)'; bi_L = sum(xji_L_model)'./sum(xji_model)';
sigma_H = 1 + theta_H(1,1)/2.46; sigma_L = 1 + theta_L(1,1)/2.46;

scale_effect_std =  r(:,1)./alpha(1,:)';
scale_effects = scale_effect_std .* (ri_H/sigma_H + ri_L/sigma_L )./ (bi_H/sigma_H + bi_L/sigma_L );

%scatter(log(w(:,1)),ri_H)

lambdaji=xji./repmat(sum(xji),N,1);
lambdaii=lambdaji(eye(N)==1); gains_std = (lambdaii ./ scale_effect_std) .^(1./theta(:,1));

 lambdaii_H = lambdaii./(bi_H + (lambdaji_L(eye(N)==1)./lambdaji_H(eye(N)==1)).*bi_L);
 lambdaii_L = lambdaii./(bi_L + (lambdaji_H(eye(N)==1)./lambdaji_L(eye(N)==1)).*bi_H);
 
 gains_H = (lambdaii_H ./ scale_effects) .^(1./theta_H(:,1)); gains_L= (lambdaii_L ./ scale_effects) .^(1./theta_L(:,1)); 
 
 gains = (gains_H.^ ei_H(eye(N)==1)) .* (gains_L.^ ei_L(eye(N)==1));


end