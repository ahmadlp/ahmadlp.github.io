clear all;
clc;
cd '~/Replication File/Industry-Level Estimation/'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Step 1. Load the Data   %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load WIOD_Data_CR2014 %% This data_set is directly taken from Costinot and Rodriguez-Clare (2014)
clearvars -except N S X_nis epsilon_cl rjs3D Y_j beta3d countries

Data = xlsread('gravity_34.xlsx'); %% Gravity Data for the 34 countries in the WIOD sample
global N S
S=15; % Number of non-service industries

Lj = Data(1:N,2);
Yj = Data(1:N,4)/10e6;
Y_j = Y_j(1,:,1)';

dist=reshape(Data(:,5)',N,N); %dist_ii=repmat(dist(eye(N)==1),1,N); 
dist3d=repmat(dist./1000, [1 1 S]);

border=reshape(Data(:,6)',N,N);
lang=reshape(Data(:,7)',N,N);

Xji3d=X_nis(:,:,1:15);

wj=Y_j./Lj;
norm=1;
wj=wj/norm;

alpha3d = repmat(sum(X_nis,1), [N 1 1])./ repmat(sum(sum(X_nis,1),3), [N 1 31]);
L3d = repmat(Lj,[1 N S]);
w3d = repmat(wj,[1 N S]);
Y3d = repmat(Y_j/norm,[1 N S]);
r3d=rjs3D(:,:,1:S);
theta3d=epsilon_cl(:,:,1:S);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Step 2. Run the Estimation Seperately for Each Industry   %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

param=zeros(S,N+5);

for s=1:15
    
    Xji=Xji3d(:,:,s)/norm; w=w3d(:,:,s); Y=Y3d(:,:,s); dist=dist3d(:,:,s); 
    r=r3d(:,:,s); alpha=alpha3d(:,:,s); theta=theta3d(:,:,s); L=r3d(:,:,s).* L3d(:,:,s);
    

target = @(X) Objective(X, Xji, w, Y, theta, dist, border, lang, alpha, L);

%%% X = [ beta_const beta_dist beta_border beta_lang rho e(N*1) ]    
%%% Note: T is estimated within the "Objective" function by iteration
GUESS = [  0.9         1.5     0.2        0.9      0.9                0.5*ones(1,N)];
LB    = [  0.1           1       0        0.5      0.5                0*ones(1,N)  ];
UB    = [  1            15       5        1.1      1.1                1*ones(1,N)  ];
  

options = optimset('Display','Iter','MaxFunEvals',40000,'MaxIter',500,'TolFun',1e-8,'TolX',1e-8);
X_sol=lsqnonlin(target,GUESS,LB, UB, options);
display(num2str(X_sol))
param(s,:) = X_sol;

end
save('param.mat','param')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Step 3. Compute the Gains from Trade & Display Results   %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%load param.mat
gains=zeros(N,S); gains_std=zeros(N,S);

%%% This loop computes the gains from trade for each Industry. 
%%% It also displays theta_H and theta_L for each industry (reported in Table 9)

for s=1:S
    
     Xji=Xji3d(:,:,s)/norm; w=w3d(:,:,s); Y=Y3d(:,:,s); dist=dist3d(:,:,s); 
    r=r3d(:,:,s); beta=beta3d(:,:,s); theta=theta3d(:,:,s); L=r3d(:,:,s).* L3d(:,:,s); alpha=alpha3d(:,:,s);
    
    [gains(:,s), gains_std(:,s)] =Post_Estimation(param(s,:), Xji, w, Y, theta, dist, border, lang, alpha, r, L);
    
    gains(:,s)=beta(1,:)'.*log(gains(:,s)); gains_std(:,s)=beta(1,:)'.*log(gains_std(:,s));
    
end
    

 %%%%%% Gains from Service Trade %%%%%%%%%%%%%%%%%%%%%%%
 aux=X_nis./repmat(sum(X_nis,1),[N 1 1]);
 gains_service = prod((aux(:,:,16:end)).^(beta3d(:,:,16:end)/5),3);
 gains_service = gains_service(eye(N)==1);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gains = 100*(1 - exp(sum(gains,2)).*gains_service);
gains_std = 100*(1 - exp(sum(gains_std,2)).*gains_service);

Xji2d=sum(Xji3d,3); dist=reshape(Data(:,5),N,N);
remote=sum(dist.*Xji2d,1)./sum(Xji2d,1);

Yj=Yj/Yj(33); Lj=Lj/Lj(33); remote=remote/remote(33);

%%% The following lines produce Table 7 in the paper %%%%

Table = [Yj Lj remote' gains_std gains gains-gains_std];

tablePreamble = {...
'\begin{tabular}{lccccccc}';
'\toprule';
'& \multicolumn{3}{c}{} &';
'\multicolumn{2}{c}{Gains from trade} & \\';
'\addlinespace[3pt]';
'\cline{5-6}';
'\addlinespace[3pt]';
'Country &';
'\specialcell{GDP \\(US=1)} &';
'\specialcell{Population \\ (US=1)} &';
'\specialcell{Remoteness\\ (US=1)} &';
'\specialcell{ACR } &';
'\specialcell{Multi-Segment Industries} &';
'\specialcell{Pure gains from \\ Within-Industry Specialization} \\'


'\midrule'
};

tableClosing = {...
'\bottomrule';
'\end{tabular}'
};

fileID = fopen('Table.tex', 'w');

%-- TABLE PREAMBLE:
for i = 1:size(tablePreamble)
    fprintf(fileID, '%s\n', char(tablePreamble(i)));
end

    %-- COLUMNS WITH RESULTS:
for i = 1:N
    fprintf(fileID, '%s & ', char(countries(i)));
    for j = 1:3
        fprintf(fileID, '%1.2f & ', Table(i, j));
    end
   
    fprintf(fileID, '%1.1f\\%% & ', Table(i, 4));
    fprintf(fileID, '%1.1f\\%% & ', Table(i, 5));
    fprintf(fileID, '%1.1f\\%% \\\\', Table(i, 6));
  
  
end

% %-- WRITE AVERAGES:
% % Extra empty line:
% fprintf(fileID, '\\\\\n');
% 
% avg = mean(Table);
% fprintf(fileID, '\\textbf{Average} & ');
% for j = 1:4
%     fprintf(fileID, '%1.1f\\%% & ', avg(j));
% end
% fprintf(fileID, '%1.3f & ', avg(5));
% fprintf(fileID, '%1.3f\\\\\n', avg(6));

%-- TABLE CLOSING:
for i = 1:size(tableClosing)
    fprintf(fileID, '%s\n', char(tableClosing(i)));
end

fclose(fileID);