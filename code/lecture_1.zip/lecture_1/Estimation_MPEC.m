clear;
clc;
cd ~/Downloads/lecture_1 % set your working directory here
%=====================================================================
% Structural Gravity: MPEC Estimation (fmincon with equilibrium constraints)
%---------------------------------------------------------------------
% This script implements Mathematical Programming with Equilibrium
% Constraints (MPEC). We estimate beta (trade-cost parameters) jointly
% with chi_i (technology terms) by minimizing the log-bilateral trade loss
% subject to the equilibrium (goods market clearing) conditions.
%
% Notation follows the lecture notes:
%  - tau_ij: iceberg trade costs
%  - chi_i: technology/productivity terms (decision variables)
%  - lambda_ij: expenditure shares
%  - E_j: total expenditure at destination j (E_j = Y_j + D_j)
%  - X_ij = lambda_ij * E_j: bilateral trade implied by the model
%  - Equilibrium: Y_i = sum_j X_ij (enforced as equality constraints)
%=====================================================================

%--------------- Load and Organize Data -----------------%
Data = xlsread('Data_Trade_50.xlsx'); 

N = 50;                        % Number of Countries
epsilon=4;                     % Trade Elasticity

data.X = Data(:,1);            % trade flows X_ij (stacked by columns j)
data.Y = Data(1:N,2);          % GDP Y_i
data.dist = Data(:,6)/1000;    % distance (thousand km)
data.border = Data(:,7);       % common border dummy
data.language = Data(:,8);     % common language dummy
data.FTA = Data(:,9);          % free trade agreement dummy

X_2D = reshape(data.X,N,N)';
X_2D(X_2D<0) = 0 ; % set negative flows to zero

% Build total expenditure 
% E_j = Y_j + imports_j - exports_j
X_ii = data.Y - sum(X_2D,2); 
data.E = sum(X_2D)' + X_ii;   

%--------- Perform Constrained Optimization ---------------%
% target: sum of squared log residuals
% constraint: goods market clearing (Y_i vs sum_j X_ij)
target = @(beta) OBJECTIVE(beta, data, N, epsilon);
constraint = @(beta) EQUILIBRIUM_CONSTRAINT(beta, data, N, epsilon);

% Initial guess and bounds
% Estimated parameters: [beta(1:5), log(chi_i)]
%   tau_ij(beta) = beta1 * dist^{beta2} * beta3^{border} * beta4^{language} * beta5^{FTA}
beta0 = [ 3     0.2   0.95  0.95  0.95    log((data.Y'/mean(data.Y))) ];
 UB   = [ 20     10    10    10    10      50*ones(1,N)            ];
 LB   = [ 0      0     0.5   0.5   0.5    -50*ones(1,N)            ];


%---------------  Perform Optimization via fmincon -----------------%
% settings for fmincon
options = optimset('Display','Iter', ...
                   'MaxFunEvals',50000, ...
                   'MaxIter',1000, ...
                   'TolFun',1e-10, ...
                   'TolX',1e-10, ...
                   'algorithm', 'sqp');

[beta_sol, fval, ~, ~ ,~, ~, Hessian ] = fmincon(target,beta0,[],[],[],[],LB,UB,constraint,options);

%---------------  Compute R-Squared and Standard Errors -----------------%

% Calculate R-squared
trade = data.X > 0;
R_Squared = 1 - ( fval / sum( ( log(data.X(trade)) - mean(log(data.X(trade))) ).^2 ));

% Compute standard errors using the robust Gauss-Newton method
[std_err_all, Cov_all, s2] = compute_se_robust(beta_sol, data, N, epsilon);
std_err_robust = std_err_all(1:5)'; % Extract SEs for the 5 beta parameters

%---------------  Display Results -----------------%
disp('--- MPEC Estimation Results (Robust SEs) ---')
disp('Parameters:  const   dist   border   language   FTA')
disp('----------------------------------------------------')
disp(['Beta est:    ', num2str(beta_sol(1:5))])
disp(['Std Err:     ', num2str(std_err_robust)])
disp('----------------------------------------------------')
disp(['R-squared = ',num2str(R_Squared)])



%% ------------- OBJECTIVE & EQUILIBRIUM FUNCTIONS ----------------

function [resid] = OBJECTIVE(beta, data, N, epsilon)

% Iceberg costs tau_ij(beta) with level/intercept
% tau_ij = beta1 * dist^{beta2} * beta3^{border} * beta4^{language} * beta5^{FTA}
tau = beta(1) .* (data.dist.^beta(2)) .* (beta(3).^data.border) ... 
               .* (beta(4).^data.language) .* (beta(5).^data.FTA);

tau_2D = reshape(tau,N,N);
tau_2D((eye(N)==1))=1;

% chi_i (technology/productivity) in 2D form
chi_2D = repmat(exp(beta(6:end))',1,N);
Yi_2D = repmat(data.Y,1,N);
Ei_2D = repmat(data.E',N,1);   % use total expenditure E_j

% Expenditure shares: lambda_ij numerator
Numer = chi_2D .* ((Yi_2D.*tau_2D).^(-epsilon));
% Bilateral flows X_ij = [ Numer_ij / sum_i Numer_ij ] * E_j
X_2D  = (Numer ./ repmat(sum(Numer),N,1)).* Ei_2D ;

% Compare log flows only where data are strictly positive
trade = data.X > 0;
X_1D = reshape(X_2D',N*N,1);
log_X_model = log(X_1D(trade));
log_X_data  = log(data.X(trade));

resid =  sum((log_X_data - log_X_model).^2);

end


function [c, ceq] = EQUILIBRIUM_CONSTRAINT(beta, data, N, epsilon)

% Iceberg costs tau_ij(beta) with level/intercept
tau = beta(1) .* (data.dist.^beta(2)).* (beta(3).^data.border)... 
             .* (beta(4).^data.language) .* (beta(5).^data.FTA);

tau_2D = reshape(tau,N,N);
tau_2D((eye(N)==1))=1;

% chi_i (technology/productivity) in 2D form
chi_2D = repmat(exp(beta(6:end))',1,N);
Yi_2D = repmat(data.Y,1,N);
Ei_2D = repmat(data.E',N,1);   % use total expenditure E_j

% Expenditure shares: lambda_ij numerator
Numer = chi_2D .* ((Yi_2D.*tau_2D).^(-epsilon));
% Bilateral flows X_ij = [ Numer_ij / sum_i Numer_ij ] * E_j
X_2D  = (Numer ./ repmat(sum(Numer),N,1)).* Ei_2D ;

% Equilibrium residuals (goods market clearing) in logs
ERR = log(sum(X_2D,2)) - log(data.Y)  ;

% Normalization to resolve chi scale indeterminacy
% Enforce geometric mean of chi_i equals 1: mean(log chi_i) = 0
norm_ceq = mean(beta(6:end));

c = [];
ceq = [ERR', norm_ceq];

end


%% -------- Function: Robust MPEC standard errors (Gauss-Newton) --------
% Computes robust standard errors for the MPEC estimator using the
% Gauss-Newton approximation to the Hessian (J'J). This avoids issues with
% non-positive definite Hessians from fmincon.
function [std_err, Cov, s2] = compute_se_robust(beta_sol, data, N, epsilon)
    
    % Define a function to compute the vector of residuals
    resid_fun = @(b) get_residuals(b, data, N, epsilon);
    
    % Get residuals at the solution
    r_hat = resid_fun(beta_sol);
    
    % Dimensions for degrees of freedom calculation
    m = numel(r_hat);         % Number of observations
    p = numel(beta_sol);      % TOTAL number of parameters (betas + chis)
    
    fprintf('Calculating Jacobian for %d parameters... this may take a moment.\n', p);
    
    % Numerically compute the Jacobian J = dr/d(beta_sol) using central differences
    J = zeros(m, p);
    h_step = 1e-6;
    for k = 1:p
        h = h_step * max(1, abs(beta_sol(k)));
        
        b_plus = beta_sol;
        b_plus(k) = b_plus(k) + h;
        
        b_minus = beta_sol;
        b_minus(k) = b_minus(k) - h;
        
        r_plus = resid_fun(b_plus);
        r_minus = resid_fun(b_minus);
        
        J(:, k) = (r_plus - r_minus) / (2*h);
    end
    
    fprintf('Jacobian calculation complete.\n');
    
    % Calculate residual sum of squares (RSS)
    RSS = r_hat' * r_hat;
    
    % Calculate residual variance with CORRECT degrees of freedom
    s2 = RSS / (m - p);
    
    % Compute the Gauss-Newton approximation of the Hessian
    H_approx = J' * J;
    
    % Compute the covariance matrix. This is guaranteed to be positive semi-definite.
    try
        Cov = s2 * inv(H_approx);
    catch
        warning('Jacobian matrix is singular. Using pseudoinverse.');
        Cov = s2 * pinv(H_approx);
    end
    
    std_err = sqrt(diag(Cov));
end

% Helper function required by compute_se_robust
function r = get_residuals(beta, data, N, epsilon)
    % This function computes model residuals given the full parameter vector
    % It is essentially a simplified version of your OBJECTIVE function
    tau = beta(1) .* (data.dist.^beta(2)) .* (beta(3).^data.border) ... 
                   .* (beta(4).^data.language) .* (beta(5).^data.FTA);
    tau_2D = reshape(tau,N,N);
    tau_2D((eye(N)==1))=1;
    
    chi_2D = repmat(exp(beta(6:end))',1,N);
    Yi_2D = repmat(data.Y,1,N);
    Ei_2D = repmat(data.E',N,1);
    
    Numer = chi_2D .* ((Yi_2D.*tau_2D).^(-epsilon));
    X_2D  = (Numer ./ repmat(sum(Numer),N,1)).* Ei_2D ;
    
    trade = data.X > 0;
    X_1D = reshape(X_2D',N*N,1);
    
    log_X_model = log(X_1D(trade));
    log_X_data  = log(data.X(trade));
    
    r = (log_X_data - log_X_model); % Note: these are the residuals r, not the sum of squares
end
