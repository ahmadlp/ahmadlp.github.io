clear
clc
%=====================================================================
% Hat Algebra Example (2-country, static gravity)
%---------------------------------------------------------------------
% This script illustrates solving for counterfactual changes using hat
% algebra. Inputs are grouped for clarity:
%  - data: baseline objects (lambda, N, Y, D)
%  - param: model parameters (epsilon)
%  - shock: exogenous changes (tau_hat, D_hat)
%=====================================================================

%---------- Baseline data ------------
data.N = 2;                                  % two countries
data.Y = [ 1 4 ]';                           % nominal GDP: [GDP_US, GDP_RoW]
data.D = [-0.04 0.04]';                      % aggregate deficits
data.lambda = [0.88 0.02  ; ...              % baseline expenditure shares
               0.12 0.98 ];
% lambda(1,1) = share of US expenditure on US goods,
% lambda(1,2) = share of RoW expenditure on US goods,
% lambda(2,1) = share of US expenditure on RoW goods, 
% lambda(2,2) = share of RoW expenditure on RoW goods. 

%---------- Model parameters ----------
param.epsilon = 5;       % trade elasticity

%---------- Shocks ----------
% Example: reduce international trade costs by 20%; domestic unchanged
shock.tau_hat = [1    0.8  ; ...
                 0.8    1 ];

shock.D_hat = ones(data.N,1);                % hold deficits fixed in hats (D_hat=1)
      
%-------- Solve for Y_hat (change in nominal GDP) --------
Y_hat_0 = ones(data.N,1); % initial guess
Y_hat_sol = fsolve(@(Y_hat) HAT_ALGEBRA(Y_hat, shock, data, param), Y_hat_0);

%-------- Report output in log changes (approx percent) --------
[~, X_hat, W_hat] = HAT_ALGEBRA(Y_hat_sol, shock, data, param);
disp(['change in US nominal GDP = ', num2str(log(Y_hat_sol(1)))])
disp(['change in US exports to the RoW = ', num2str(log(X_hat(1,2)))])
disp(['change in US imports from the RoW = ', num2str(log(X_hat(2,1)))])
disp(['change in US real GDP (welfare) = ', num2str(log(W_hat(1)))])


%% -------- Function: System of Equilibrium Conditions ------------
function [ERR, X_hat, W_hat] = HAT_ALGEBRA(Y_hat, shock, data, param)

N = data.N;              % number of countries
lambda = data.lambda;    % baseline shares
Y = data.Y;              % baseline GDP
D = data.D;              % baseline deficits
epsilon = param.epsilon; % trade elasticity

% Unit-cost hats c_hat_ij = tau_hat_ij * Y_hat_i
c_hat = shock.tau_hat .* repmat(Y_hat,1,N);

% Expenditure shares under the shock: lambda' = lambda * c_hat^{-epsilon} / sum_i(...)
lambda_prime = lambda .* (c_hat.^-epsilon) ./ repmat( sum(lambda.* (c_hat.^-epsilon) ), N,1);

% Expenditures under the shock: E'_j = Y_hat_j * Y_j + D'_j
D_prime = D.*shock.D_hat;
E_prime = repmat(Y_hat' .* Y' + D_prime',N,1);

% Bilateral trade and market clearing
X_prime = lambda_prime .* E_prime ;
Y_prime = Y_hat.* Y;
ERR = Y_prime - sum( X_prime , 2); % goods market clearing condition

%----- Variables of interest (hats) -------
X = lambda.*repmat(Y'+ D',N,1) ;
X_hat = X_prime ./ X;
lambda_hat = lambda_prime./lambda;
W_hat = ( lambda_hat(eye(N)==1) ).^(-1/epsilon); % real income (welfare)

end
