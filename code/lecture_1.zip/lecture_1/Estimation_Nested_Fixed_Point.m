clear;
clc;
cd ~/Downloads/lecture_1 % set your working directory here
%=====================================================================
% Structural Gravity: Nested Fixed-Point Estimation (NLS over beta)
%---------------------------------------------------------------------
% This script estimates a structural gravity trade model by
% nested fixed point (NFP): for each candidate parameter vector beta,
% the inner loop solves for technology terms chi_i that clear goods
% markets, and the outer loop chooses beta to match logged bilateral
% trade flows in least squares.
%
% Notation follows the lecture notes:
%  - tau_ij(beta): iceberg trade costs, parameterized by distance, border,
%                  language, and FTA dummies (multiplicative form)
%  - c_ij = tau_ij * Y_i: unit-cost shifter used here (Y_i proxies w_i)
%  - chi_i: technology/productivity term that clears markets in equilibrium
%  - lambda_ij: expenditure shares = [chi_i * c_ij^(-epsilon)] / sum_i(...)
%  - E_j: total expenditure at destination j (E_j = Y_j + D_j)
%  - X_ij = lambda_ij * E_j: bilateral nominal trade implied by the model
%  - epsilon: trade elasticity
%
% Data contain imbalances; we construct E_j from observed flows so that
% columns of X match total expenditure. The objective compares log(X_ij)
% vs log(data.X_ij) for positive flows only.
%=====================================================================

%--------------- Load and Organize Data -----------------%
Data = xlsread('Data_Trade_50.xlsx');

N = 50;                        % Number of Countries
epsilon=4;                     % Trade Elasticity

data.X = Data(:,1);            % trade flows X_ij (stacked by columns j)
data.Y = Data(1:N,2);          % GDP Y_i
data.dist = Data(:,6)/1000;    % distance (thousand km)
data.border = Data(:,7);       % common border dummy 1{border_ij}
data.language = Data(:,8);     % common language dummy 1{lang_ij}
data.FTA = Data(:,9);          % free trade agreement dummy 1{fta_ij}

% Build total expenditure E_j to allow for trade imbalances
X_2D = reshape(data.X,N,N)';
X_2D(X_2D<0) = 0 ;
X_ii = data.Y - sum(X_2D,2); 
data.E = sum(X_2D)' + X_ii;    % E_j = imports_j + domestic absorption

%---------------  Perform Optimization -----------------%

% Outer problem: choose beta to minimize sum of squared residuals
% residuals are log(X_ij^model) - log(X_ij^data) for X_ij^data > 0

% settings for lsqnonlin
options = optimset('Display','Iter',...
                   'MaxFunEvals',40000, ...
                   'MaxIter',30,...
                   'TolFun',1e-12,...
                   'TolX',1e-12);

% Define objective function for lsqnonlin
target = @(beta) Objective(beta, data, N, epsilon);
% Initial guess and bounds for beta
beta_0 = [ 2     0.1   1     1     1  ]; 
UB    =  [ 20    10    10    10    10    ];
LB    =  [ 0     0     0     0     0     ];

[beta_sol, resnorm, ~, ~, ~, ~, J] = lsqnonlin(target,beta_0,LB,UB,options);

%---------------  Display Results -----------------%

trade = data.X > 0;
RSS = resnorm;                         % sum of squared residuals
m = sum(trade);                        % number of residuals (positive flows)
p = numel(beta_sol);                   % number of parameters

% Compute homoskedastic NLS SEs using Gauss–Newton formula
[std_err, Cov, s2] = compute_nls_se(J, RSS, m, p);

R_Squared = 1 - ( RSS / sum( ( log(data.X(trade)) - mean(log(data.X(trade))) ).^2 ));

disp('beta_const  beta_dist beta_border beta_language beta_FTA')
disp(num2str(beta_sol(1:5)))
disp(num2str(std_err(1:5)'))
disp(['R-squared = ',num2str(R_Squared)])


%% ------------- OBJECTIVE FUNCTION ----------------

function [resid] = Objective(beta, data, N, epsilon)

d = beta(1) * (data.dist.^beta(2)) .* (beta(3).^data.border) ...
                    .* (beta(4).^data.language) .* (beta(5).^data.FTA);

% Iceberg costs with domestic costs normalized to 1
tau = reshape(d,N,N); tau((eye(N)==1))=1;

% Inner-loop state: initialize chi_i (technology) using a common shortcut
chi = (data.Y).^epsilon; % good initial guess: scales with size

eps=1; % initial error
rep=0; % initialize iteration counter

while (eps>1e-10) && (rep<5000)
    % Unit costs c_ij = tau_ij * Y_i (Y_i proxies cost shifter w_i)
    c = tau.*repmat(data.Y,1,N);

    % Expenditure share numerators: chi_i * c_ij^{-epsilon}
    P = chi .* c.^(-epsilon);

    % Expenditure shares lambda_ij = P_ij / sum_i P_ij
    lambda = P ./ repmat(sum(P),N,1);

    % Bilateral nominal trade: X_ij = lambda_ij * E_j
    X = lambda .* repmat(data.E',N,1);

    % Market clearing (goods): Y_i(model) = sum_j X_ij
    Y_model = sum(X,2);

    % Update chi via damped multiplicative correction to clear markets
    % increase chi_i if the model under-predicts Y_i, and vice versa
    eps = max(abs(log(data.Y) - log(Y_model)));
    alpha = 0.25;   % damping for stability
    chi = chi .* (data.Y ./ Y_model).^alpha;

    rep = rep + 1;
end

% Stack and compare only strictly positive "trade" flows (data.X > 0)
trade = data.X > 0;
X_1D = reshape(X',N*N,1);
log_X_model = log(X_1D(trade));
log_X_data  = log(data.X(trade));

% Return residual vector for lsqnonlin
resid = (log_X_model - log_X_data);
end


%% -------- Helper: NLS standard errors from Jacobian --------
% Given the Jacobian J of the residual vector r(beta) at the solution,
% and the residual sum of squares RSS = r'r, the Gauss–Newton covariance
% for nonlinear least squares is Cov(beta) ≈ s^2 * (J'J)^{-1}, where
% s^2 = RSS / (m - p), with m residuals and p parameters. This mirrors
% the linear regression case and is appropriate when the Jacobian is a
% good local approximation and errors are homoskedastic.
function [std_err, Cov, s2] = compute_nls_se(J, RSS, m, p)
    H = J' * J;                        % approximate Hessian (Gauss–Newton)
    s2 = RSS / max(m - p, 1);          % residual variance estimate
    try
        Cov = s2 * inv(H);% solve rather than invert
    catch
        Cov = s2 * pinv(H);            % safe fallback if near-singular
    end
    std_err = sqrt(diag(Cov));
end
